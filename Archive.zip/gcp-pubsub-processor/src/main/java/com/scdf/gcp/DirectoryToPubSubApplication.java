package com.scdf.gcp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import com.google.cloud.spring.pubsub.core.publisher.PubSubPublisherTemplate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

@SpringBootApplication
@EnableScheduling
public class DirectoryToPubSubApplication {

    public static void main(String[] args) {
        SpringApplication.run(DirectoryToPubSubApplication.class, args);
    }

    @Autowired
    private PubSubPublisherTemplate pubSubTemplate;

    @Value("${spring.cloud.stream.bindings.fileReader.destination}")
    String topic;

    @Value("${file.directory}")
    String fileDirectory;

    @Bean
    public Consumer<String> fileReader() {
        return (line) -> {
            System.out.println("Publishing to pubsub: " + line);
            pubSubTemplate.publish(topic, line);
            System.out.println("Data published to pub sub : " + line);
        };
    }

    @Scheduled(fixedRate = 60000) // Schedule to run every 60 seconds
    public void readDirectoryAndProcess() throws IOException, InterruptedException {
        Path directoryPath = Paths.get(fileDirectory);

        try (Stream<Path> files = Files.walk(directoryPath)) {
            files.filter(Files::isRegularFile)
                    .forEach(this::processFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processFile(Path filePath) {
        Faker faker = new Faker();
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> writeLines = new ArrayList<>();
        try {
            for (int i = 1; i < 100; i++) {
                String firstName = faker.name().firstName();
                String lastName = faker.name().lastName();
                writeLines.add(objectMapper.writeValueAsString(
                        Account.builder().id(String.valueOf(i)).name(firstName + " " + lastName).build()));
            }
            // Write lines to the file
            Files.write(filePath, writeLines);
            System.out.println("Data written to file successfully.");

            List<String> lines = Files.readAllLines(filePath);
            lines.stream().filter(StringUtils::isNotBlank).forEach(line -> fileReader().accept(line));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
