CREATE SCHEMA IF NOT EXISTS cache_accounts;

CREATE TABLE cache_accounts.account (
    id varchar(100) NOT NULL,
    name varchar(255) NOT NULL,
    PRIMARY KEY (ID)
);