/*
package com.scdf.gcp;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.SQLException;

@Slf4j
@Component
public class SchemaConfig implements BeanPostProcessor {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Value("${database.schema.create:false}")
    private boolean cleanDatabase;

    @Value("${db.schema}")
    private String schemaName;


    @SneakyThrows
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

        if (cleanDatabase) {
            log.info("Going to delete DB schema '{}' if exists.", schemaName);
            jdbcTemplate.execute("DROP SCHEMA IF EXISTS " + schemaName + " CASCADE");
        }
        log.info("Going to create DB schema '{}' if not exists.", schemaName);
        jdbcTemplate.execute("create schema if not exists " + schemaName);
        log.info("Created schema for app " + schemaName);
        return bean;
    }
}
*/
