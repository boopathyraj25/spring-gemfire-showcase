package com.scdf.gcp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Configuration
public class TaskConfig {

    @Value("${account.data.count:100}")
    private int accountCount;

    // Insert data into Postgres SQL and Redis when the task is executed
    @Bean
    public CommandLineRunner commandLineRunner(JdbcTemplate jdbcTemplate, StringRedisTemplate redisTemplate) {
        return args -> {
            //Delete existing data into account table
            jdbcTemplate.execute("truncate cache_accounts.account");
            log.info("Existing data from account table deleted successfully");

            // Insert into Postgres SQL
            Faker faker = new Faker();
            List<Account> accounts = new ArrayList<>();
            for (int i = 1; i < accountCount + 1; i++) {
                String firstName = faker.name().firstName();
                String lastName = faker.name().lastName();
                accounts.add(Account.builder().id(String.valueOf(i)).name(firstName + " " + lastName).build());
            }
            String insertSQL = "INSERT INTO cache_accounts.account (id, name) VALUES(?, ?)";
            // Using batchUpdate to insert multiple records
            jdbcTemplate.batchUpdate(insertSQL, accounts, accounts.size(),
                    (ac, account) -> {
                        ac.setString(1, account.getId());
                        ac.setString(2, account.getName());
                    });
            log.info("Data inserted into Cloud SQL successfully");

            // Insert into Redis (Memory store)
            Map<String, String> data = new HashMap<>();
            ObjectMapper objectMapper = new ObjectMapper();
            for (Account account : accounts) {
                data.put("Account:" + account.getId(), objectMapper.writeValueAsString(account));
            }
            redisTemplate.opsForValue().multiSet(data);
            log.info("Data inserted into Memory store successfully.");
        };
    }
}
